# Promotion Protocol

## Stages

1. Raw note in vault.
2. Structured analysis in vault.
3. Record or sync to Notion Enrichment Hub.
4. Approval gate.
5. Promotion package.
6. Main repo issue / ADR / implementation plan.
7. PR / migration / tests.
8. Validation and Notion sync.

## Approval gates

- `APPROVE SLICE PLANNING`
- `APPROVE IMPLEMENTATION PLAN`
- `APPROVE REPO CHANGES`

## Promotion package checklist

- [ ] Problem statement
- [ ] Business box / workstream
- [ ] User persona
- [ ] Workflow trigger
- [ ] Desired outcome
- [ ] Scope
- [ ] Non-goals
- [ ] Existing table fit
- [ ] Migration impact
- [ ] RLS impact
- [ ] UI routes
- [ ] Test plan
- [ ] Rollback plan
- [ ] Notion records linked or identified
- [ ] Decision owner
