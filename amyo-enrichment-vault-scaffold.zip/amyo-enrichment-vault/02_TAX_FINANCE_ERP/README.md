# Tax and Finance ERP Research

Purpose: research and plan AMYO tax/finance architecture without prematurely altering the main repo or Supabase schema.

Core principle: source verification first.

Research domains:

- VAT and e-tax
- Withholding tax
- Excise tax
- Pension
- Profit tax
- Electronic receipt enforcement
- Single window import/export
- Payments and transaction records
- Multiple accounts and financial records
